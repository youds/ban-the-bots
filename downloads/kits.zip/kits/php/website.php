<!-- Include This URL After The Body Tag; Only Bots See It. -->
<a href="<?php echo 'blackhole' . rand(0, 10) ?>" style="display:none;">Blackhole</a>