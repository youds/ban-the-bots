<?php session_start(); if ($_SESSION['BOT'] == 'BANNED') exit('Thanks for visiting.'); ?>
